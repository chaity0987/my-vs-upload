import { Patient, Donor, TransfusionRecord, BloodRequest, ContactMessage } from '../types';

export const api = {
  // Health
  async checkHealth() {
    try {
      const res = await fetch('/api/health');
      return await res.json();
    } catch (e) {
      return null;
    }
  },

  // Auth / Login
  async phoneLogin(phoneNumber: string, role?: 'patient' | 'donor') {
    try {
      const res = await fetch('/api/auth/phone-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phoneNumber, role }),
      });
      return await res.json();
    } catch (e) {
      console.error('API phoneLogin error:', e);
      return null;
    }
  },

  // Patients
  async getPatient(phone?: string): Promise<Patient | null> {
    try {
      const url = phone ? `/api/patients?phone=${encodeURIComponent(phone)}` : '/api/patients';
      const res = await fetch(url);
      const data = await res.json();
      return data.patient || null;
    } catch (e) {
      console.error('API getPatient error:', e);
      return null;
    }
  },

  async savePatient(patient: Patient): Promise<Patient | null> {
    try {
      const res = await fetch('/api/patients', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(patient),
      });
      const data = await res.json();
      return data.patient || patient;
    } catch (e) {
      console.error('API savePatient error:', e);
      return patient;
    }
  },

  async deletePatient(id?: string): Promise<boolean> {
    try {
      const url = id ? `/api/patients/${id}` : '/api/patients';
      const res = await fetch(url, { method: 'DELETE' });
      const data = await res.json();
      return data.success;
    } catch (e) {
      console.error('API deletePatient error:', e);
      return false;
    }
  },

  // Donors
  async getDonors(params?: { bloodGroup?: string; district?: string; availabilityStatus?: string; search?: string }): Promise<Donor[]> {
    try {
      const searchParams = new URLSearchParams();
      if (params?.bloodGroup) searchParams.set('bloodGroup', params.bloodGroup);
      if (params?.district) searchParams.set('district', params.district);
      if (params?.availabilityStatus) searchParams.set('availabilityStatus', params.availabilityStatus);
      if (params?.search) searchParams.set('search', params.search);

      const qs = searchParams.toString();
      const res = await fetch(`/api/donors${qs ? `?${qs}` : ''}`);
      const data = await res.json();
      return data.donors || [];
    } catch (e) {
      console.error('API getDonors error:', e);
      return [];
    }
  },

  async saveDonor(donor: Donor): Promise<Donor | null> {
    try {
      const res = await fetch('/api/donors', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(donor),
      });
      const data = await res.json();
      return data.donor || donor;
    } catch (e) {
      console.error('API saveDonor error:', e);
      return donor;
    }
  },

  async deleteDonor(id: string): Promise<boolean> {
    try {
      const res = await fetch(`/api/donors/${id}`, { method: 'DELETE' });
      const data = await res.json();
      return data.success;
    } catch (e) {
      console.error('API deleteDonor error:', e);
      return false;
    }
  },

  // Transfusions
  async getTransfusions(): Promise<TransfusionRecord[]> {
    try {
      const res = await fetch('/api/transfusions');
      const data = await res.json();
      return data.transfusions || [];
    } catch (e) {
      console.error('API getTransfusions error:', e);
      return [];
    }
  },

  async recordTransfusion(record: TransfusionRecord): Promise<TransfusionRecord[]> {
    try {
      const res = await fetch('/api/transfusions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(record),
      });
      const data = await res.json();
      return data.transfusions || [];
    } catch (e) {
      console.error('API recordTransfusion error:', e);
      return [];
    }
  },

  async updateTransfusion(record: TransfusionRecord): Promise<TransfusionRecord[]> {
    try {
      const res = await fetch(`/api/transfusions/${record.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(record),
      });
      const data = await res.json();
      return data.transfusions || [];
    } catch (e) {
      console.error('API updateTransfusion error:', e);
      return [];
    }
  },

  async deleteTransfusion(id: string): Promise<TransfusionRecord[]> {
    try {
      const res = await fetch(`/api/transfusions/${id}`, { method: 'DELETE' });
      const data = await res.json();
      return data.transfusions || [];
    } catch (e) {
      console.error('API deleteTransfusion error:', e);
      return [];
    }
  },

  // Blood Requests
  async getBloodRequests(): Promise<BloodRequest[]> {
    try {
      const res = await fetch('/api/blood-requests');
      const data = await res.json();
      return data.requests || [];
    } catch (e) {
      console.error('API getBloodRequests error:', e);
      return [];
    }
  },

  async createBloodRequest(request: BloodRequest): Promise<BloodRequest[]> {
    try {
      const res = await fetch('/api/blood-requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(request),
      });
      const data = await res.json();
      return data.requests || [];
    } catch (e) {
      console.error('API createBloodRequest error:', e);
      return [];
    }
  },

  async updateBloodRequestStatus(id: string, status: string): Promise<BloodRequest[]> {
    try {
      const res = await fetch(`/api/blood-requests/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
      const data = await res.json();
      return data.requests || [];
    } catch (e) {
      console.error('API updateBloodRequestStatus error:', e);
      return [];
    }
  },

  // Contact Messages
  async sendMessage(msg: ContactMessage): Promise<boolean> {
    try {
      const res = await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(msg),
      });
      const data = await res.json();
      return data.success;
    } catch (e) {
      console.error('API sendMessage error:', e);
      return false;
    }
  },
};
