import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";

// Initial Seed Data
const INITIAL_DEMO_DONORS = [
  {
    id: 'DON-101',
    fullName: 'Tanvir Ahmed',
    age: 26,
    gender: 'Male',
    bloodGroup: 'B+',
    phoneNumber: '01711234567',
    district: 'Dhaka',
    upazila: 'Dhanmondi',
    lastDonationDate: '2026-05-12',
    availabilityStatus: 'Available',
    totalDonations: 8,
    registeredAt: '2026-01-10',
    isFictionalDemo: true,
  },
  {
    id: 'DON-102',
    fullName: 'Fatema Tuz Zohra',
    age: 24,
    gender: 'Female',
    bloodGroup: 'O+',
    phoneNumber: '01822334455',
    district: 'Dhaka',
    upazila: 'Mirpur',
    lastDonationDate: '2026-04-20',
    availabilityStatus: 'Available',
    totalDonations: 5,
    registeredAt: '2026-02-14',
    isFictionalDemo: true,
  },
  {
    id: 'DON-103',
    fullName: 'Rahat Hossain',
    age: 29,
    gender: 'Male',
    bloodGroup: 'A+',
    phoneNumber: '01933445566',
    district: 'Chattogram',
    upazila: 'Agrabad',
    lastDonationDate: '2026-06-01',
    availabilityStatus: 'Available',
    totalDonations: 12,
    registeredAt: '2025-11-20',
    isFictionalDemo: true,
  },
  {
    id: 'DON-104',
    fullName: 'Nusrat Jahan',
    age: 23,
    gender: 'Female',
    bloodGroup: 'AB+',
    phoneNumber: '01644556677',
    district: 'Sylhet',
    upazila: 'Sylhet Sadar',
    lastDonationDate: '2026-03-15',
    availabilityStatus: 'Available',
    totalDonations: 4,
    registeredAt: '2026-03-01',
    isFictionalDemo: true,
  },
  {
    id: 'DON-105',
    fullName: 'Mahmudul Hasan',
    age: 31,
    gender: 'Male',
    bloodGroup: 'O-',
    phoneNumber: '01755667788',
    district: 'Rajshahi',
    upazila: 'Boalia',
    lastDonationDate: '2026-05-25',
    availabilityStatus: 'Available',
    totalDonations: 15,
    registeredAt: '2025-08-15',
    isFictionalDemo: true,
  },
  {
    id: 'DON-106',
    fullName: 'Sabrina Akter',
    age: 27,
    gender: 'Female',
    bloodGroup: 'A-',
    phoneNumber: '01866778899',
    district: 'Dhaka',
    upazila: 'Uttara',
    lastDonationDate: '2026-07-28',
    availabilityStatus: 'Currently Unavailable',
    totalDonations: 6,
    registeredAt: '2026-01-25',
    isFictionalDemo: true,
  },
  {
    id: 'DON-107',
    fullName: 'Asif Rahman',
    age: 28,
    gender: 'Male',
    bloodGroup: 'B-',
    phoneNumber: '01977889900',
    district: 'Khulna',
    upazila: 'Sonadanga',
    lastDonationDate: '2026-04-10',
    availabilityStatus: 'Available',
    totalDonations: 9,
    registeredAt: '2025-10-05',
    isFictionalDemo: true,
  },
  {
    id: 'DON-108',
    fullName: 'Fahim Shakil',
    age: 25,
    gender: 'Male',
    bloodGroup: 'AB-',
    phoneNumber: '01588990011',
    district: 'Barishal',
    upazila: 'Barishal Sadar',
    lastDonationDate: '2026-05-18',
    availabilityStatus: 'Available',
    totalDonations: 3,
    registeredAt: '2026-04-02',
    isFictionalDemo: true,
  },
  {
    id: 'DON-109',
    fullName: 'Shamsul Alam',
    age: 33,
    gender: 'Male',
    bloodGroup: 'B+',
    phoneNumber: '01799001122',
    district: 'Mymensingh',
    upazila: 'Mymensingh Sadar',
    lastDonationDate: '2026-06-14',
    availabilityStatus: 'Available',
    totalDonations: 11,
    registeredAt: '2025-09-12',
    isFictionalDemo: true,
  },
  {
    id: 'DON-110',
    fullName: 'Mehnaz Chowdhury',
    age: 26,
    gender: 'Female',
    bloodGroup: 'O+',
    phoneNumber: '01811223344',
    district: 'Rangpur',
    upazila: 'Rangpur Sadar',
    lastDonationDate: '2026-05-02',
    availabilityStatus: 'Available',
    totalDonations: 7,
    registeredAt: '2026-02-18',
    isFictionalDemo: true,
  }
];

const INITIAL_DEMO_REQUESTS = [
  {
    id: 'REQ-2026-801',
    patientName: 'Ayaan Haque (Age 7)',
    bloodGroup: 'B+',
    hospitalName: 'Dhaka Shishu (Children) Hospital',
    requiredDate: '2026-08-25',
    requiredUnits: 1,
    contactNumber: '01712987654',
    district: 'Dhaka',
    notes: 'Regular thalassemia transfusion requirement. Filtered fresh red blood cells needed.',
    status: 'Urgent',
    createdAt: '2026-08-20',
  },
  {
    id: 'REQ-2026-802',
    patientName: 'Sadia Karim (Age 12)',
    bloodGroup: 'O-',
    hospitalName: 'BSMMU (PG Hospital), Shahbagh',
    requiredDate: '2026-08-26',
    requiredUnits: 2,
    contactNumber: '01833449988',
    district: 'Dhaka',
    notes: 'Rare negative blood group required for child thalassemia patient.',
    status: 'Urgent',
    createdAt: '2026-08-19',
  },
  {
    id: 'REQ-2026-803',
    patientName: 'Tanvir Islam (Age 15)',
    bloodGroup: 'A+',
    hospitalName: 'Chattogram Medical College Hospital',
    requiredDate: '2026-08-28',
    requiredUnits: 1,
    contactNumber: '01922331100',
    district: 'Chattogram',
    notes: 'Transfusion due date approaching in 3 days. Patient Hb is 7.2 g/dL.',
    status: 'In Progress',
    createdAt: '2026-08-18',
  }
];

// Persistent File-backed storage
const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

interface DatabaseSchema {
  users: Array<{
    id: string;
    phoneNumber: string;
    role: 'patient' | 'donor';
    patientId?: string;
    donorId?: string;
    createdAt: string;
  }>;
  patients: Array<any>;
  donors: Array<any>;
  transfusions: Array<any>;
  bloodRequests: Array<any>;
  messages: Array<any>;
}

function loadDB(): DatabaseSchema {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (fs.existsSync(DB_FILE)) {
      const raw = fs.readFileSync(DB_FILE, 'utf-8');
      return JSON.parse(raw);
    }
  } catch (err) {
    console.error('Error loading DB file, fallback to default:', err);
  }

  const defaultDB: DatabaseSchema = {
    users: [],
    patients: [],
    donors: INITIAL_DEMO_DONORS,
    transfusions: [],
    bloodRequests: INITIAL_DEMO_REQUESTS,
    messages: [],
  };
  saveDB(defaultDB);
  return defaultDB;
}

function saveDB(db: DatabaseSchema) {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving DB file:', err);
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // In-memory sync with persistent json
  let db = loadDB();

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", service: "Thalcare BD Backend API", timestamp: new Date().toISOString() });
  });

  // --- Auth / Phone Verification ---
  app.post("/api/auth/phone-login", (req, res) => {
    const { phoneNumber, role } = req.body;
    if (!phoneNumber) {
      return res.status(400).json({ error: "Phone number is required" });
    }

    const cleanPhone = phoneNumber.trim().replace(/\s+/g, '');
    let user = db.users.find(u => u.phoneNumber.replace(/\s+/g, '') === cleanPhone);

    const matchedPatient = db.patients.find(p => p.phoneNumber?.replace(/\s+/g, '') === cleanPhone);
    const matchedDonor = db.donors.find(d => d.phoneNumber?.replace(/\s+/g, '') === cleanPhone);

    if (!user) {
      user = {
        id: `USR-${Date.now()}`,
        phoneNumber: cleanPhone,
        role: role || (matchedPatient ? 'patient' : matchedDonor ? 'donor' : 'patient'),
        patientId: matchedPatient?.id,
        donorId: matchedDonor?.id,
        createdAt: new Date().toISOString(),
      };
      db.users.push(user);
      saveDB(db);
    }

    res.json({
      success: true,
      user,
      patient: matchedPatient || null,
      donor: matchedDonor || null,
    });
  });

  // --- Patient API Endpoints ---
  // Get active/stored patient (or by phone)
  app.get("/api/patients", (req, res) => {
    const { phone } = req.query;
    if (phone) {
      const clean = String(phone).trim().replace(/\s+/g, '');
      const found = db.patients.find(p => p.phoneNumber?.replace(/\s+/g, '') === clean);
      return res.json({ patient: found || null });
    }
    // Return the latest active registered patient or all
    const latest = db.patients.length > 0 ? db.patients[db.patients.length - 1] : null;
    res.json({ patient: latest, total: db.patients.length });
  });

  // Save / Register / Update Patient
  app.post("/api/patients", (req, res) => {
    const patientData = req.body;
    if (!patientData || !patientData.fullName || !patientData.bloodGroup) {
      return res.status(400).json({ error: "Patient fullName and bloodGroup are required" });
    }

    const patientId = patientData.id || `PAT-${Date.now()}`;
    const newPatient = {
      ...patientData,
      id: patientId,
      registeredAt: patientData.registeredAt || new Date().toISOString(),
    };

    const existingIdx = db.patients.findIndex(p => p.id === patientId || p.phoneNumber === patientData.phoneNumber);
    if (existingIdx >= 0) {
      db.patients[existingIdx] = newPatient;
    } else {
      db.patients.push(newPatient);
    }
    saveDB(db);

    res.json({ success: true, patient: newPatient });
  });

  // Delete Patient
  app.delete("/api/patients/:id?", (req, res) => {
    const { id } = req.params;
    if (id) {
      db.patients = db.patients.filter(p => p.id !== id);
    } else {
      // Clear current patient
      db.patients = [];
    }
    saveDB(db);
    res.json({ success: true, message: "Patient profile deleted successfully" });
  });

  // --- Donor API Endpoints ---
  // Get all donors / Search donors by blood group, district, status
  app.get("/api/donors", (req, res) => {
    const { bloodGroup, district, availabilityStatus, search } = req.query;
    let result = [...db.donors];

    if (bloodGroup) {
      result = result.filter(d => d.bloodGroup === bloodGroup);
    }
    if (district) {
      result = result.filter(d => d.district?.toLowerCase() === String(district).toLowerCase());
    }
    if (availabilityStatus && availabilityStatus !== 'all') {
      result = result.filter(d => d.availabilityStatus === availabilityStatus);
    }
    if (search) {
      const q = String(search).toLowerCase();
      result = result.filter(d =>
        d.fullName?.toLowerCase().includes(q) ||
        d.district?.toLowerCase().includes(q) ||
        d.upazila?.toLowerCase().includes(q) ||
        d.phoneNumber?.includes(q)
      );
    }

    res.json({ donors: result, count: result.length });
  });

  // Register or Update Donor
  app.post("/api/donors", (req, res) => {
    const donorData = req.body;
    if (!donorData || !donorData.fullName || !donorData.bloodGroup || !donorData.phoneNumber) {
      return res.status(400).json({ error: "Donor fullName, bloodGroup, and phoneNumber are required" });
    }

    const donorId = donorData.id || `DON-${Date.now()}`;
    const newDonor = {
      ...donorData,
      id: donorId,
      registeredAt: donorData.registeredAt || new Date().toISOString(),
    };

    const existingIdx = db.donors.findIndex(d => d.id === donorId || d.phoneNumber === donorData.phoneNumber);
    if (existingIdx >= 0) {
      db.donors[existingIdx] = newDonor;
    } else {
      db.donors.unshift(newDonor);
    }
    saveDB(db);

    res.json({ success: true, donor: newDonor });
  });

  // Delete Donor
  app.delete("/api/donors/:id", (req, res) => {
    const { id } = req.params;
    db.donors = db.donors.filter(d => d.id !== id);
    saveDB(db);
    res.json({ success: true, message: "Donor removed from registry", donors: db.donors });
  });

  // --- Transfusion History API ---
  // Get transfusions
  app.get("/api/transfusions", (req, res) => {
    const sorted = [...db.transfusions].sort(
      (a, b) => new Date(b.transfusionDate).getTime() - new Date(a.transfusionDate).getTime()
    );
    res.json({ transfusions: sorted });
  });

  // Record a transfusion
  app.post("/api/transfusions", (req, res) => {
    const record = req.body;
    if (!record || !record.transfusionDate || !record.hospitalName) {
      return res.status(400).json({ error: "Transfusion date and hospital name are required" });
    }

    const newRecord = {
      ...record,
      id: record.id || `TR-${Date.now()}`,
      createdAt: record.createdAt || new Date().toISOString(),
    };

    db.transfusions.unshift(newRecord);

    // Auto-update patient lastTransfusionDate if patient exists
    if (db.patients.length > 0) {
      db.patients[0].lastTransfusionDate = record.transfusionDate;
    }

    saveDB(db);
    res.json({ success: true, transfusion: newRecord, transfusions: db.transfusions });
  });

  // Update transfusion
  app.put("/api/transfusions/:id", (req, res) => {
    const { id } = req.params;
    const updated = req.body;
    db.transfusions = db.transfusions.map(t => (t.id === id ? { ...t, ...updated } : t));
    saveDB(db);
    res.json({ success: true, transfusions: db.transfusions });
  });

  // Delete transfusion
  app.delete("/api/transfusions/:id", (req, res) => {
    const { id } = req.params;
    db.transfusions = db.transfusions.filter(t => t.id !== id);
    saveDB(db);
    res.json({ success: true, transfusions: db.transfusions });
  });

  // --- Emergency Blood Requests API ---
  app.get("/api/blood-requests", (req, res) => {
    res.json({ requests: db.bloodRequests });
  });

  app.post("/api/blood-requests", (req, res) => {
    const reqData = req.body;
    if (!reqData || !reqData.patientName || !reqData.bloodGroup || !reqData.contactNumber) {
      return res.status(400).json({ error: "Patient name, blood group, and contact number are required" });
    }

    const newReq = {
      ...reqData,
      id: reqData.id || `REQ-${Date.now()}`,
      status: reqData.status || 'Urgent',
      createdAt: reqData.createdAt || new Date().toISOString(),
    };

    db.bloodRequests.unshift(newReq);
    saveDB(db);
    res.json({ success: true, request: newReq, requests: db.bloodRequests });
  });

  app.put("/api/blood-requests/:id", (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    db.bloodRequests = db.bloodRequests.map(r => (r.id === id ? { ...r, status: status || r.status } : r));
    saveDB(db);
    res.json({ success: true, requests: db.bloodRequests });
  });

  // --- Contact Messages API ---
  app.get("/api/messages", (req, res) => {
    res.json({ messages: db.messages });
  });

  app.post("/api/messages", (req, res) => {
    const msg = req.body;
    const newMsg = {
      ...msg,
      id: `MSG-${Date.now()}`,
      submittedAt: new Date().toISOString(),
    };
    db.messages.unshift(newMsg);
    saveDB(db);
    res.json({ success: true, message: newMsg });
  });

  // --- Reset Seed Data ---
  app.post("/api/reset", (req, res) => {
    db = {
      users: [],
      patients: [],
      donors: INITIAL_DEMO_DONORS,
      transfusions: [],
      bloodRequests: INITIAL_DEMO_REQUESTS,
      messages: [],
    };
    saveDB(db);
    res.json({ success: true, message: "Database reset to initial demo seeds" });
  });

  // Vite middleware for development & static fallback for production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Thalcare BD Backend Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
